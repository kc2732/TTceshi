<?php
include 'head.php';
include 'top-bar.php';
include 'index-content.php';
?>

<!--<body>-->
<!--    <form action="workout.php" method="post">-->
<!--        Please enter your user name:<input type="text" name="username">-->
<!--        password:<input type="text" name="password">-->
<!---->
<!--        <input type="submit">-->
<!--    </form>-->
<!---->
<!--</body>-->
