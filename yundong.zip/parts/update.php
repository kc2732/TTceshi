<?php
/**
 * Created by PhpStorm.
 * User: PC
 * Date: 2016/5/11
 * Time: 22:11
 */
$id = $_POST['Id'];
$username = $_POST['username'];
$password = $_POST['password'];
$phone = $_POST['phone'];

$hostname = 'localhost';
$username = 'chenkun';
$password = 'chenkun';
$mysql = mysql_connect($hostname,$username,$password);
mysql_select_db('yundong',$mysql);
if($_POST['option'] == 'insert'){
    $sql = "INSERT INTO YUNDONG VALUES('$Id','$username','$password','$phone')";
    mysql_query($sql) or die(mysql_error());
} elseif($_POST['option'] == 'update'){

}
?>
