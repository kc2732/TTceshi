<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8' />
    <meta name="viewport" content="width=device-width" />
    <link rel='stylesheet' href='../lib/cupertino/jquery-ui.min.css' />
    <link href='../fullcalendar.css' rel='stylesheet' />
    <link href='../fullcalendar.print.css' rel='stylesheet' media='print' />
    <link href="../css/bootstrap.min.css" rel="stylesheet"/>
    <link href="../css/style.css" rel="stylesheet" />
    <link href="../css/responsive.css" rel="stylesheet" />
    <script src='../lib/moment.min.js'></script>
    <script src='../lib/jquery.min.js'></script>
    <script src='../fullcalendar.min.js'></script>
    <script src='../lang-all.js'></script>
    <script src="../js/bootstrap.min.js"></script>
    <style>

        /*body {*/
            /*margin: 0;*/
            /*padding: 0;*/
            /*font-family: "Lucida Grande",Helvetica,Arial,Verdana,sans-serif;*/
            /*font-size: 14px;*/
        /*}*/

        /*#top {*/
            /*background: #eee;*/
            /*border-bottom: 1px solid #ddd;*/
            /*padding: 0 10px;*/
            /*line-height: 40px;*/
            /*font-size: 12px;*/
        /*}*/

        #calendar {
            max-width: 900px;
            margin: 40px auto;
            padding: 0 10px;
        }

    </style>

    <script type="text/javascript">

        $(document).ready(function() {
            var currentLangCode = 'zh-cn';

            // build the language selector's options
            $.each($.fullCalendar.langs, function(langCode) {
                $('#lang-selector').append(
                    $('<option/>')
                        .attr('value', langCode)
                        .prop('selected', langCode == currentLangCode)
                        .text(langCode)
                );
            });

            // rerender the calendar when the selected option changes
            $('#lang-selector').on('change', function() {
                if (this.value) {
                    currentLangCode = this.value;
                    $('#calendar').fullCalendar('destroy');
                    renderCalendar();
                }
            });

            function renderCalendar() {
                $('#calendar').fullCalendar({
                    header: {
                        left: 'prev,next today',
                        center: 'title',
                        right: 'month,agendaWeek,agendaDay'
                    },
//				defaultDate: '2016-05-12',
                    lang: currentLangCode,
                    buttonIcons: false, // show the prev/next text
                    weekNumbers: true,
                    editable: true,
                    eventLimit: true,// allow "more" link when too many events
                    dayClick: function(date, jsEvent, view) {
                        console.log(date.format());
                        var day = new Date(date.format());
                        var day_right = day.getDay()+1;
                        window.location.assign('index.php?date='+ day_right);
//                        alert('Clicked on: ' + date.format());
//
//                        alert('Coordinates: ' + jsEvent.pageX + ',' + jsEvent.pageY);
//
//                        alert('Current view: ' + view.name);

                        // change the day's background color just for fun
                        $(this).css('background-color', 'grey');

                    }
                });
            }

            renderCalendar();
        });

        $('#calendar').fullCalendar({

        });
    </script>

</head>
