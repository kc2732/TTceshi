<div class="content-top">

   创建您的运动医生账户！

</div>

<div class="body-container">
    <div class="col-sm-7 col-md-7 col-lg-8 content-left">


        <img src="../images/content_left.jpg"style="width: 80%; margin:0 10% 5% 10%;">

        个性化生活调优计划从现在开始

    </div>
    <div class="col-sm-5 col-md-5 col-lg-4 content-right" style="">
        <div style="padding: 25px;">
            <form action="update.php" method="post">
                <fieldset>
                    <legend style="">
                        <strong>用户名</strong>
                    </legend>
                    <input type="text" name="username" required>
                </fieldset>

                <fieldset>

                    <legend><strong>密码</strong></legend>
                    <input type="password" id="password1" name="password" required>

                </fieldset>

                <fieldset>

                    <legend><strong>重新输入</strong></legend>
                    <input type="password" id="password2" required>

                </fieldset>

                <fieldset>

                    <legend><strong>电话号码</strong></legend>
                    <input type="text" name="phone" required>

                </fieldset>
                <fieldset>
                    <input type="checkbox" required style="margin-left: 15px;">我已阅读并同意<a href="../运动处方试用协议.pdf">运动处方试用协议</a>.
                </fieldset>

                <input type="hidden" name="option" value="insert">
                <fieldset>
                    <input class="button-submit button-register" type="submit" name="submit">
                </fieldset>
            </form>
        </div>
    </div>
</div>
<script>

    (function() {
        var password1 = document.getElementById('password1');
        var password2 = document.getElementById('password2');

        var checkPasswordValidity = function() {
            if (password1.value != password2.value) {
                password2.setCustomValidity('两次密码输入不一致，请检查后再重新提交');
            } else {
                password2.setCustomValidity('');
            }
        };

        password1.addEventListener('change', checkPasswordValidity, false);
        password2.addEventListener('change', checkPasswordValidity, false);

        var form = document.getElementById('passwordForm');
        form.addEventListener('submit', function(event) {
            checkPasswordValidity();
            if (!this.checkValidity()) {
                event.preventDefault();
                //Implement you own means of displaying error messages to the user here.
                password1.focus();
            }
        }, false);
    }());

</script>
</div>